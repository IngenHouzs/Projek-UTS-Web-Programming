<?php 

    header('location: app/index.php');
    die();

?>