<?php 
    if (isset($_SESSION['id_user'])){
        header('location: index.php');
        die();
    }
?>